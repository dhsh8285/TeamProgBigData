package com.teamprog.vo;

public class LunchVO extends boardVO {

//	int num;
//	String name;
//	String time;
//	String title;
//	String content;
//	int viewcnt;
	double point;
	String location;
	String menu;
	String sort;
}
