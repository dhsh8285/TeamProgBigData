package com.teamprog.vo;

public class boardVO {
	int num;
	String name;
	String time;
	String title;
	String content;
	int viewcnt;
	public boardVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public boardVO(int num, String name, String time, String title, String content, int viewcnt) {
		super();
		this.num = num;
		this.name = name;
		this.time = time;
		this.title = title;
		this.content = content;
		this.viewcnt = viewcnt;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getViewcnt() {
		return viewcnt;
	}
	public void setViewcnt(int viewcnt) {
		this.viewcnt = viewcnt;
	}
	
}
